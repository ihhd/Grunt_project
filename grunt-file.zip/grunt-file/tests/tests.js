QUnit.test("hello test",function(assert){
    assert.ok(1=="1","passed..!!");
})